<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Clendario_modulos extends Model
{
    //
}
