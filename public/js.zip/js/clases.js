$(document).ready(function () {

    $('#data_1 .input-group.date').datepicker({
        language: 'es',
        todayBtn: "linked",
        calendarWeeks: true,
        autoclose: true,
    });

    $('#tbl-clases').DataTable({
        processing: true,
        serverSide: true,
        ajax: 'clases/all',
        columns: [
            {
                sortable: false,
                "render": function (data, type, full, meta) {
                    //var btn_delete = " <a onclick=\"eliminar(" + full.id + ","+true+")\" class='btn btn-outline btn-danger btn-xs' data-toggle='tooltip' data-placement='top' title='Eliminar'><i class='fa fa-trash'></i></a> ";
                    var btn_edit =  "<a href='clases/" + full.id + "/edit' class='btn btn-white btn-sm'><i class='fa fa-folder'></i> Detalles </a> ";
                    return btn_edit ;
                }
            },
            {
                searchable: true,
                className: 'project-title',
                "render": function (data, type, full, meta) {
                    var inicio = moment(full.fecha_inicio).format('DD-MM-YYYY')
                    var fin = moment(full.fecha_fin).format('DD-MM-YYYY')
                    return  "<a href='clases/" + full.id + "/edit'>Múdolo "+full.modulo+"</a><br/><small>Inicio: "+inicio+" - Fin: "+fin+"</small>";
                }
            },
            { 
                "render": function (data, type, full, meta) {
                    return "<span class='label label-"+full.clase_estado+"'>"+ full.estado+"</span>";                    
                }
            },
            { data: "sede", name: 'sede'},
            { data: "cant", name: 'cant'},
            {
                className: 'project-title',
                sortable: false,
                "render": function (data, type, full, meta) {
                    var salones = full.salon.replace(',', '<br>');
                    return salones;
                }
            },
            { data: "jornada", name: 'jornada'},
            {
                sortable: false,
                "render": function (data, type, full, meta) {
                    var porcentaje = full.completadas/full.total*100;
                    var btn_progreso =  "<small>Conpletadas: "+full.completadas+" de "+full.total+"</small><div class='progress progress-mini'><div style='width: "+porcentaje+"%;background-color: #1c84c6' class='progress-bar'></div></div>";
                    return btn_progreso;
                }
            },
            {
                "render": function (data, type, full, meta) {
                    if (roles.includes('Administrador') || roles.includes('Coordinador')) {
                        if (full.profesor_id == 'null' || full.profesor_id == null || full.profesor_id == 'NULL' ) {
                            return  "<a href=''>Sin asignar</a>";
                        }else{
                            return  "<a href=''><img alt='image' width='60px' class='img-circle' src='"+full.profesor_img+"'> "+full.profesor+"</a>";                        
                        }
                    }
                    if (roles.includes('Profesor')) {
                        return 'Próxima fecha';
                    }
                }
            }
        ]
    });

});

var objVue = new Vue({
    el: '#clases',
    data:{
        salon:'',
        programa:'',
        capacidad:'',
        ubicacion:'',
        duracion:'',
        jornada:'',
        sede:'',
        dato_profesor: '',
        profesor_asignado: '',
        dato_estudiante: '',
        estudiantes_inscritos: {},
        programas: {},
        hora_inicio_jornada: '',
        hora_fin_jornada: '',
        cargando_programa: 0,
        estudiantes: {},
        profesores: {},
        formErrors: {}
    },
    methods:{
        get_profesor_asignado: function(){
            axios.get('profesor_asignado').then(response => {
                if (response.data[0].profesor.length > 0) {
                    this.profesor_asignado = response.data[0].profesor;   
                }
            });
        }
    }
    
});