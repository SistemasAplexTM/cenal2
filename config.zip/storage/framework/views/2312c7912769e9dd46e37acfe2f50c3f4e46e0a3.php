<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no">
    <meta name="mobile-web-app-capable" content=yes>
    <link rel="icon" sizes="192x192" href="<?php echo e(asset('img/logo_cenal.png')); ?>">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> | CENAL</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/plantilla.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/fullcalendar.print.css')); ?>" rel="stylesheet" media='print'>
</head>
<body  class="top-navigation skin-1">
    <div id="wrapper">            
        <div id="page-wrapper" class="gray-bg">
            <?php if(!Auth::guest()): ?>
                <?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
            <div class="wrapper wrapper-content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
<!-- Scripts -->
    <script src="<?php echo e(asset('js/plantilla.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
      <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
