@extends('layouts.app')
@section('title', 'perfil')
@section('content')
<h1>Hola</h1>
@endsection