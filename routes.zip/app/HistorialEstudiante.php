<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HistorialEstudiante extends Model
{
    protected $table = 'historial_estudiante';
}
