<div class="row border-bottom white-bg">
    <nav class="navbar navbar-static-top" role="navigation">
        <div class="navbar-header">
            <button aria-controls="navbar" aria-expanded="false" data-target="#navbar" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                <i class="fa fa-reorder"></i>
            </button>
            <a href="<?php echo e(route('home')); ?>" class="navbar-brand">CENAL</a>
        </div>
        <div class="navbar-collapse collapse" id="navbar">
            <ul class="nav navbar-nav">
                
                <li>
                    <a href="<?php echo e(url('/clases')); ?>"><i class="fa fa-calendar"></i> <span class="nav-label">Módulos programados</span> </a>
                </li>
                <?php if(Auth::user()->rol == 2): ?>
                <li>
                    <a href="<?php echo e(url('/admin/clases')); ?>"><i class="fa fa-gears"></i> <span class="nav-label">Configuración académica</span> </a>
                </li>
                <?php endif; ?>
                
                
                <?php if(auth()->check() && auth()->user()->hasRole('Administrador|Coordinador')): ?>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"><i class="fa fa-gears"></i> <span class="nav-label">Administración</span> </a>
                    
                      
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                        <li>
                            <a href="<?php echo e(url('programas')); ?>"><i class="fa fa-briefcase"></i> <span class="nav-label">Programas</span> </a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('salon')); ?>"><i class="fa fa-home"></i> <span class="nav-label">Salones</span> </a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('modulo')); ?>"><i class="fa fa-puzzle-piece"></i> <span class="nav-label">Módulos</span> </a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('ubicacion')); ?>"><i class="fa fa-map-marker"></i> <span class="nav-label">Ubicación</span> </a>
                        </li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver_usuarios')): ?>
                            <li>
                                <a href="<?php echo e(url('user')); ?>"><i class="fa fa-user"></i> <span class="nav-label">Usuarios</span> </a>
                            </li>
                        <?php endif; ?>
                      </ul>
                    
                </li>
                <?php endif; ?>
            </ul>
            <ul class="nav navbar-top-links navbar-right">
                <?php if(Auth::user()->rol == 0): ?>
                <?php if(auth()->check() && auth()->user()->hasRole('Estudiante')): ?>
                <li>
                    <a href="<?php echo e(url('/estudiante/perfil')); ?>"><i class="fa fa-user-circle"></i> <span class="nav-label">Perfil</span> </a>
                </li>
                <?php endif; ?>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasRole('Administrador')): ?>
                <li><a href="<?php echo e(route('clients')); ?>"><i class="fa fa-code"></i> Soy desarrollador</a></li>
                <?php endif; ?>
                <?php if(Auth::guest()): ?>
                <li>
                    <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
                        <i class="fa fa-sign-out"></i> Entrar
                    </a>
                </li>
                <?php else: ?>
                <li>
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                        <i class="fa fa-sign-out"></i> Salir
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</div>