<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no">
    <meta name="mobile-web-app-capable" content=yes>
    <link rel="icon" sizes="192x192" href="<?php echo e(asset('img/logo_cenal.png')); ?>">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>CENAL</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/plantilla.css')); ?>" rel="stylesheet">
</head>
<body class="gray-bg">
    <div class="middle-box text-center loginscreen animated fadeInDown">
        <div>
            <div>
                <h5 class="logo-name">
                    <img src="<?php echo e(asset('img/logo_cenal.png')); ?>" alt="">
                </h5>
            </div>
            <h3>Bienvenido a CENAL</h3>
            <!-- <p><small>CENTRO NACIONAL DE CAPACITACIÓN LABORAL</small></p> -->
            <?php if(session('change_password')): ?>
                <div class="alert alert-warning">
                    <h4><?php echo e(session('change_password')); ?></h4>
                    <p>Debes cambiar tu contraseña para poder usar la plataforma.</p>
                </div>
            <?php endif; ?>
            <form id="form-login" class="m-t" role="form" method="POST" action="<?php echo e(url('change_password')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                   <input 
                    name="password"
                    type="password"
                    class="form-control"
                    placeholder="Contraseña nueva"
                    required=""
                    value="<?php echo e(old('password')); ?>" 
                    >
                </div>
                <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                    <input name="password_confirmation" type="password" class="form-control" placeholder="Confirmar contraseña" required="">
                    <?php echo $errors->first('password', '<span class="help-block">:message</span>'); ?>

                </div>
                <button type="submit" class="btn btn-success block full-width m-b">Cambiar</button>
                
                
                
            </form>
                <?php if(Auth::guest()): ?>
                <a class="btn btn-sm btn-white btn-block" href="<?php echo e(route('home')); ?>">
                    <i class="fa fa-home"></i> Inicio
                </a>
                <?php else: ?>
                <a class="btn btn-sm btn-white btn-block" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                    <i class="fa fa-sign-out"></i> Salir
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>
                <?php endif; ?>
        </div>
    </div>
</div>
  <script src="<?php echo e(asset('js/plantilla.js')); ?>"></script>
</body>
</html>