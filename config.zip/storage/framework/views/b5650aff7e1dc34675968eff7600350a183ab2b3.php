<?php $__env->startSection('title', 'Perfil'); ?>
<?php $__env->startSection('content'); ?>
<style>
    #modal-edit{
      width: 100% !important;
    }
  </style>
<div class="row animated fadeInRight">
    <?php if(session('mora')): ?>
        <div class="alert alert-danger">
            <h2>Mensajdelkmlkmdflskm</h2>
        </div>
    <?php endif; ?>
    <div class="col-md-4">
        <div class="ibox float-e-margins">
            <div class="ibox-title">
                <h5>
                    <i class="fa fa-user-circle"></i> Perfil
                </h5>
                <div class="ibox-tools">
                    <a data-toggle="modal" title="Actualizar datos" data-target="#modal-edit" class="">Editar <i class="fa fa-edit"></i></a>
                </div>
            </div>
            <div>
                <div class="ibox-content no-padding border-left-right">
                    <?php if($data->genero_id == 1): ?>
                        <a type="button" data-toggle="modal" data-target="#modal-img">
                            <img alt="image" class="img-responsive " src="<?php echo e(asset('img/user-default.png')); ?>">
                        </a>
                    <?php elseif($data->genero_id == 1): ?>
                        <img alt="image" class="img-responsive" src="<?php echo e(asset('img/user-default-f.png')); ?>">
                    <?php else: ?>
                        <img alt="image" class="img-responsive" src="<?php echo e(asset('img/user-update.png')); ?>">
                    <?php endif; ?>
                </div>
                <div class="ibox-content profile-content">
                    <p class="no-margins">
                        <span class="label label-success"><i class="fa fa-barcode"></i> <?php echo e($data->consecutivo); ?></span>
                    </p>
                    <h4><strong><?php echo e($data->nombres . ' ' .$data->primer_apellido . ' ' . $data->segundo_apellido); ?></strong>&nbsp;<span class="badge badge-success"> <?php echo e($data->sede); ?> &nbsp;<i class="fa fa-map-marker"></i></span></h4>
                    <p><i class="fa fa-id-card-o icon-separed" ></i><?php echo e($data->num_documento); ?></p>
                    <p><i class="fa fa-envelope icon-separed" ></i><?php echo e($data->correo); ?></p>
                    <div class="user-button">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="btn-group pull-right">
                                    <button data-toggle="dropdown" class="btn btn-danger btn-sm dropdown-toggle">Certificados <span class="caret"></span></button>
                                    <ul class="dropdown-menu">
                                        <li><a href="#">Certificado 01</a></li>
                                        <li><a href="#">Certificado 02</a></li>
                                        <li><a href="#">Certificado 03</a></li>
                                    </ul>
                                </div>
                                <hr>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="tabs-container">
            <ul class="nav nav-tabs">
                <li class="active"><a data-toggle="tab" href="#tab-1"><i class="fa fa-money"></i>Financiero</a></li>
                <li><a data-toggle="tab" href="#" ><i class="fa fa-clock-o"></i>Calificaciones</a></li>
                <li><a data-toggle="tab" href="#" ><i class="fa fa-clock-o"></i>Asistencia</a></li>
            </ul>
            <div class="tab-content">
                <div id="tab-1" class="tab-pane active">
                    <div class="panel-body">
                        <table class="table table-striped" id="tbl-finanzas">
                            <thead>
                            <tr>
                                <th>Estado</th>
                                <th>Concepto</th>
                                <th>Fecha</th>
                                <th>Valor</th>
                                <th>Días</th>
                                <th>Observación</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $finanzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                        <?php if($val->dias == 0): ?>
                                            <span class="label label-primary"><i class="fa fa-check"></i> Pagado</span>
                                        <?php elseif($val->dias > 0 && $val->dias < 6): ?>
                                            <span class="label label-danger"><i class="fa fa-exclamation-circle"></i> En mora</span>
                                        <?php else: ?>
                                            <span class="label label-warning"><i class="fa fa-exclamation"></i> Pendiente</span>
                                        <?php endif; ?>
                                        </td>
                                        <td><?php echo e($val->descripcion); ?></td>
                                        <td><?php echo e($val->fecha_inicio); ?></td>
                                        <td>$ <?php echo e(number_format($val->cuota,2)); ?></td>
                                        <td><?php echo e(($val->dias == 0)? '' : $val->dias); ?></td>
                                        <td><?php echo e($val->observacion); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div id="tab-2" class="tab-pane">
                    <div class="panel-body">
                       <div class="col-md-6">
                            <div class="ibox float-e-margins">
                                <div class="ibox-title">
                                    <h5>Pagado</h5>
                                </div>
                                <div class="ibox-content">
                                    <div class="table-responsive">
                                        <table class="table table-bordered" id="tbl-recibos-pagados" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Fecha</th>
                                                    <th>Valor</th>
                                                    <th>Descuento</th>
                                                    <th>Neto</th>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                       <div class="col-md-6">
                            <div class="ibox float-e-margins">
                                <div class="ibox-title">
                                    <h5>Pendiente </h5>
                                </div>
                                <div class="ibox-content">
                                    <div class="table-responsive">
                                        <table class="table table-bordered" id="tbl-pendiente" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Descripción</th>
                                                    <th>Fecha</th>
                                                    <th>Cuota</th>
                                                    <th>Saldo vencido</th>
                                                    <th>Días</th>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="tab-3" class="tab-pane">
                    <div class="panel-body">
                       

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal de imagen-->
<div id="modal-img" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Imágen de perfil</h4>
      </div>
      <div class="modal-body">
        <img alt="image" class="img-responsive" src="<?php echo e(asset('img/user-default.png')); ?>">
        <div class="row">
            <input type="file" class="form-control">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">cerrar</button>
      </div>
    </div>

  </div>
</div>
<!-- Modal de editar-->
<div id="modal-edit" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content animated flipInY">
    <form action="<?php echo e(url('estudiante/perfil/update')); ?>/<?php echo e($data->id); ?>" method="POST">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Imágen de perfil</h4>
      </div>
      <div class="modal-body">
             <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">Nombre</label>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user"></i></span>
                            <input name="nombres" type="text" class="form-control" value="<?php echo e($data->nombres); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Primer apellido</label>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user"></i></span>
                            <input name="primer_apellido" type="text" class="form-control" value="<?php echo e($data->primer_apellido); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Segundo apellido</label>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user"></i></span>
                            <input name="segundo_apellido" type="text" class="form-control" value="<?php echo e($data->segundo_apellido); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Correo</label>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input name="correo" type="text" class="form-control" value="<?php echo e($data->correo); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Fecha de nacimiento: <?php echo e(date('d-m-Y', strtotime(trim($data->fecha_nacimiento)))); ?></label>
                        <div id="data_1">
                            <div class="input-group date">
                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                <input name="fecha_nacimiento" id="fecha_nacimiento" type="text" class="form-control" placeholder="aaaa-mm-dd" autocomplete="off">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">Documento</label>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-id-card-o"></i></span>
                            <input class="form-control" value="<?php echo e($data->num_documento); ?>" readonly="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Lugar de expedición</label>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
                            <input name="expedicion_documento" type="text" class="form-control" value="<?php echo e($data->expedicion_documento); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Dirección</label>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
                            <input name="direccion" type="text" class="form-control" value="<?php echo e($data->direccion); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Celular</label>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-mobile-phone"></i></span>
                            <input name="tel_movil" type="text" class="form-control" value="<?php echo e($data->tel_movil); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Teléfono</label>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                            <input name="tel_fijo" type="text" class="form-control" value="<?php echo e($data->tel_fijo); ?>">
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">Libreta militar</label>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-address-card"></i></span>
                            <input name="num_libreta" type="text" class="form-control" value="<?php echo e($data->num_libreta); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Nivel de estudio</label>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-graduation-cap"></i></span>
                            <select name="nivel_academico_id" class="form-control">
                                <?php $__currentLoopData = $nivel_academico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n_a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($n_a->id); ?>" <?php echo e($n_a->id == $data->nivel_academico_id ? 'selected' : ''); ?>>
                                        <?php echo e($n_a->descripcion); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Institución</label>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-university"></i></span>
                            <input name="institucion" type="text" class="form-control" value="<?php echo e($data->institucion); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Estado civil</label>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-blind"></i></span>
                            <select name="estado_civil_id" class="form-control">
                                <?php $__currentLoopData = $estado_civil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e_c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($e_c->id); ?>" <?php echo e($e_c->id == $data->estado_civil_id ? 'selected' : ''); ?>>
                                        <?php echo e($e_c->descripcion); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Ocupación</label>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-briefcase"></i></span>
                            <input name="ocupacion" type="text" class="form-control" value="<?php echo e($data->ocupacion); ?>">
                        </div>
                    </div>
                </div>
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">cerrar</button>
        <button type="submit" class="btn btn-success btn-sm"><i class="fa fa-save"></i>&nbsp;Actualizar</button>
      </div>
    </form>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/perfil.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>