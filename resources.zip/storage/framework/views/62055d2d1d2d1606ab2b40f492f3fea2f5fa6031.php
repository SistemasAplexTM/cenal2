<?php $__env->startSection('title', 'perfil'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<h1>Clases</h1>
	<div class="ibox-content">
	    <div id="calendar"></div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/clases_profesor.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>