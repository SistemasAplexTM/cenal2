<?php $__env->startSection('title', 'Clases'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid" id="clases">
    <div class="row animated fadeInDown">
        <div class="col-lg-4">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Módulo</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">
                    <div id='external-events'>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="m-b-md text-center">
                                    <h3>Módulo Office</h3>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-4">
                                <dl class="">
                                    <dt>Salón:</dt> <dd>Sistemas</dd>
                                    <dt>Cupos totales:</dt> <dd> 20</dd>
                                </dl>
                            </div>
                            <div class="col-lg-4" id="cluster_info">
                                <dt>Inicio:</dt> <dd>16 Enero 2018</dd>
                                <dt>Cupos usados:</dt> <dd>  16 </dd>
                            </div>
                            <div class="col-lg-4" id="cluster_info">
                                <dt>Fin:</dt> <dd>  20 junio 2018</dd>
                                <dt>Profesor:</dt> <dd><a href="#" class="text-navy">Julio Castañeda</a> </dd>
                                    
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <dd>
                                    <div class="progress progress-striped active m-b-sm">
                                        <div style="width: 50%;" class="progress-bar"></div>
                                    </div>
                                    <small>Se han dictado <strong>10</strong> clases de 20 en total.</small>
                                </dd>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="ibox float-e-margins">
                <div class="ibox-content">
                    <div class="feed-activity-list">
                        <div class="feed-element">
                            <a href="#" class="pull-left">
                                <img alt="image" class="img-circle" src="<?php echo e(asset('img/profile_small.jpg')); ?>">
                            </a>
                            <div class="media-body ">
                                <strong>Jhonny Poconuco</strong><br>
                                <small class="text-muted"><strong>Asistencia:</strong> 03 / 15</small><br>
                                <small class="text-muted"><strong>Programa:</strong> Técnico en sistemas</small>
                            </div>
                        </div>
                        <div class="feed-element">
                            <a href="#" class="pull-left">
                                <img alt="image" class="img-circle" src="<?php echo e(asset('img/profile_small.jpg')); ?>">
                            </a>
                            <div class="media-body ">
                                <strong>Jhonny Poconuco</strong><br>
                                <small class="text-muted"><strong>Asistencia:</strong> 03 / 15</small><br>
                                <small class="text-muted"><strong>Programa:</strong> Técnico en sistemas</small>
                            </div>
                        </div>
                        <div class="feed-element">
                            <a href="#" class="pull-left">
                                <img alt="image" class="img-circle" src="<?php echo e(asset('img/profile_small.jpg')); ?>">
                            </a>
                            <div class="media-body ">
                                <strong>Jhonny Poconuco</strong><br>
                                <small class="text-muted"><strong>Asistencia:</strong> 03 / 15</small><br>
                                <small class="text-muted"><strong>Programa:</strong> Técnico en sistemas</small>
                            </div>
                        </div>
                        <div class="feed-element">
                            <a href="#" class="pull-left">
                                <img alt="image" class="img-circle" src="<?php echo e(asset('img/profile_small.jpg')); ?>">
                            </a>
                            <div class="media-body ">
                                <strong>Jhonny Poconuco</strong><br>
                                <small class="text-muted"><strong>Asistencia:</strong> 03 / 15</small><br>
                                <small class="text-muted"><strong>Programa:</strong> Técnico en sistemas</small>
                            </div>
                        </div>
                        <div class="feed-element">
                            <a href="#" class="pull-left">
                                <img alt="image" class="img-circle" src="<?php echo e(asset('img/profile_small.jpg')); ?>">
                            </a>
                            <div class="media-body ">
                                <strong>Jhonny Poconuco</strong><br>
                                <small class="text-muted"><strong>Asistencia:</strong> 03 / 15</small><br>
                                <small class="text-muted"><strong>Programa:</strong> Técnico en sistemas</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Clases </h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">
                    <div id="calendar"></div>
                </div>
            </div>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/clases.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>