<?php $__env->startSection('title', 'Módulos programados'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid" id="clases">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox">
                <div class="ibox-title">
                    <h5><i class="fa fa-calendar"></i> Módulos programados</h5>
                    <div class="ibox-tools">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('crear_clase')): ?>
                        <a href="<?php echo e(route('clases.create')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-calendar-plus-o"></i> Programar módulo</a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="ibox-content">
                    <div class="project-list">
                        <table class="table table-hover" id="tbl-clases">
                            <thead>
                                <tr>
                                    <th>Acciones</th>
                                    <th>Módulo</th>
                                    <th>Estado</th>
                                    
                                    <th>Sede</th>
                                    
                                    <th>Salón</th>
                                    <th>Jornada</th>
                                    <th>Progreso</th>
                                    <?php if(auth()->check() && auth()->user()->hasRole('Profesor')): ?>
                                    <th>Próxima clase</th>
                                    <?php else: ?>
                                    <th>Profesor</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="mdl-agregar-estudiante" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Agregar estudiante a la clase</h4>
      </div>
      <div class="modal-body">
        <div class="ibox">
            <div class="ibox-title">
                <h5><i class="fa fa-calendar-plus-o"></i> Clases</h5>
            </div>
            <div class="ibox-content">
                <h3>Módulo Office</h3>
                <small>Inicio: 01 enero 2018 - fin: 05 junio 2018</small>
            </di>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
        <button type="button" class="btn btn-primary">Agregar</button>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/clases.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>