<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pivot_programas_unicos_programas extends Model
{
    //
}
