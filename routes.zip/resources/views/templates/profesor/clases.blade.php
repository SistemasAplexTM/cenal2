@extends('layouts.app')
@section('title', 'perfil')
@section('content')
<div class="container">
	<h1>Clases</h1>
	<div class="ibox-content">
	    <div id="calendar"></div>
	</div>
</div>
@endsection