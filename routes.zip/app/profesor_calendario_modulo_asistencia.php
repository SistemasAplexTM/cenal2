<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class profesor_calendario_modulo_asistencia extends Model
{
    //
}
