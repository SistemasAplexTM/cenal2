<?php $__env->startSection('title', 'Clientes'); ?>
<?php $__env->startSection('content'); ?>
<div class="container" id="clients">
	<div class="row">
		<passport-personal-access-tokens></passport-personal-access-tokens>
		
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/clients.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>