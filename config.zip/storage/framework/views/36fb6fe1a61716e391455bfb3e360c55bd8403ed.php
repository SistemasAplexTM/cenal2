<?php $__env->startSection('title', 'Clases'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-lg-4">
            <div class="ibox float-e-margins">
            	<div class="ibox-title">
                    <h5>Datos para el profesor</h5>
                </div>
                <div class="ibox-content">
                    <div class="feed-activity-list">
                        <div class="feed-element">
                        </div>
                        <div class="feed-element" v-for="estudiante in estudiantes_inscritos">
                            <div class="feed-element">
                                <a href="#" class="pull-left">
                                    
                                </a>
                                <div class="media-body" v-if="">
                                    <strong>{{ estudiante.nombre }}</strong><br>
                                    <small class="text-muted"><strong>Asistencia:</strong> {{ estudiante.cant_asistencias }} / 10</small><br>
                                    <small class="text-muted"><strong>Programa:</strong> {{ estudiante.programa }}</small>
                                </div>
                            </div>    
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-8">
        	<div class="ibox float-e-margins">
            	<div class="ibox-title">
                    <h5>Clases</h5>
                </div>
				<div class="ibox-content">
				    <div id="calendar"></div>
				</div>
			</div>
        </div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/clases_profesor.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>