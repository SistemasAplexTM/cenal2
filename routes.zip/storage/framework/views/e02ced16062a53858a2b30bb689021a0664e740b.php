<?php $__env->startSection('title', 'Módulos'); ?>
<?php $__env->startSection('content'); ?>
<div class="container" id="crud_modulo">
	<h1 class="center">Módulos</h1>
	<form action="">
		<div class="form-group" :class="{'has-error': formErrors.nombre}">
			<div class="input-group">
		      <input type="text" class="form-control" id="modulo" v-model="nombre" placeholder="Nombre de módulo..."  @click="deleteError('nombre')">
		      <div class="btn btn-primary input-group-addon" @click.prevent="store" v-if="editar==0">Agregar</div>
		      <div class="btn btn-primary input-group-addon" @click.prevent="update" v-if="editar==1">Actualizar</div>
		      <div class="btn btn-default input-group-addon"  @click.prevent="cancel" v-if="editar==1">Cancelar</div>
		    </div>
	      	<small class="help-block result-nombre" v-show="formErrors.nombre"></small>
		</div>
	</form>
	<table class="table table-stripped" id="tbl-modulos">
		<thead>
			<tr>
				<th>Item</th>
				<th>Nombre</th>
				<th>Acciones</th>
			</tr>
		</thead>
		<tbody></tbody>
	</table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/modulo.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>