<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class estudiante_calendario_modulo_asistencia extends Model
{
    //
}
